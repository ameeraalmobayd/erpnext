# -*- coding: utf-8 -*-
# Copyright (c) 2020, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt
from __future__ import unicode_literals

# import frappe
import unittest

class TestDunningType(unittest.TestCase):
	pass
